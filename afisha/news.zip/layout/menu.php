<nav class="navbar navbar-fixed-top navbar-dark bg-inverse">
    <a class="navbar-brand" href="#">Админка</a>
    <ul class="nav navbar-nav">
        <li class="nav-item">
            <a class="nav-link" href="/admin.php?load=event">События</a>
        </li>
        <li class="nav-item">
            <a class="nav-link" href="/admin.php?load=categories">Категория событий</a>
        </li>
        <li class="nav-item">
            <a class="nav-link" href="/admin.php?load=exit">Выход</a>
        </li>
    </ul>
</nav>